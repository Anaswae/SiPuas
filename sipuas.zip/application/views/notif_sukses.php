<div class= "container">
	<div class= "form-responden">
		<div class="panel panel-primary">
			<div class="panel-body">
				<span class="glyphicon glyphicon-thumbs-up glyphicon-align-left" aria-hidden="true"></span>
			    Terima Kasih Atas Partisipasi Anda Dalam Pengisian Kuisioner SiPuas 
			</div>
			<a href="<?php echo base_url("");?>">
			<button type="button" class="btn btn-default" aria-label="Left Align" style="margin-left: 10px;">
			  <span class="glyphicon glyphicon-arrow-left glyphicon-align-left" aria-hidden="true"></span>
			  Kembali
			</button>
		</a>
		</div>
	</div>
</div>
<?php header("Refresh: 3;url=".base_url(""));?>