<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type='text/javascript'
	src="<?php echo base_url('/assets/js/jquery.min.js'); ?>"></script>
	
<script type='text/javascript'
	src="<?php echo base_url('/assets/js/jquery.dataTables.min.js'); ?>"></script>
	
<script type='text/javascript'
	src="<?php echo base_url('/assets/js/bootstrap.js'); ?>"></script>

<script type='text/javascript'
	src="<?php echo base_url('/assets/js/dataTables.bootstrap.js'); ?>"></script>
	
<?php if (empty($useSimple)){?>
<script src="<?php echo base_url('/assets/js/msdnaa.js'); ?>"></script>
<?php }?>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script
	src="<?php echo base_url('/assets/js/ie10-viewport-bug-workaround.js'); ?>"></script>
</body>
</html>