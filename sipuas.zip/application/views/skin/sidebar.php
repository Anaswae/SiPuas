<div class="col-sm-3 col-md-2 sidebar">
	<ul class="nav nav-sidebar">
		<li id="dashboard"><a href="<?php echo site_url('administrasi/dashboard');?>">Beranda</a></li>
		<li id="all"><a href="<?php echo site_url('administrasi/lihat_respon');?>">Lihat Semua Respon</a></li>
	</ul>
</div>